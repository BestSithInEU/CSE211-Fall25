#include <iostream>

using namespace std;

size_t countOccurrences(const LinkedList<T>& list, const T& value){
	
}


void swapAdjacent(LinkedList<T>& list){
	
	
}



void rotateRight(LinkedList<T>& list, size_t k){
	
	
}


void partitionAroundValue(LinkedList<T>& list, const T& pivot){
	
	
}


int main(){
	

	return 0;
}
