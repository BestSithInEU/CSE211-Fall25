#include "StackQuestionsNonMember.h"
#include <algorithm>
#include <cctype>
#include <sstream>
#include <stdexcept>
using namespace std;

namespace StackUtils {

// ============================================================================
// Question 4: Simplify Unix Path
// ============================================================================
std::string simplifyPath(const std::string &path) {
	Stack<T>temp=;
	Stack<T>temp2;
	temp.push(string);
	while(!temp.isEmpty()){
		char i =temp.pop();
		if(i="."){
			return;
		}else if(i="/"){
			temp2.push(i);
		}else{
			temp2.push(i);
		}
		
	}
  // TODO: Implement this function
}

} // namespace StackUtils
