#ifndef STACK_QUESTIONS_NON_MEMBER_TPP
#define STACK_QUESTIONS_NON_MEMBER_TPP

#include "StackQuestionsNonMember.h"

namespace StackUtils {

// ============================================================================
// Question 3: Interleave Halves
// ============================================================================
// template <typename T> void interleaveHalves(Stack<T>& stack){
 Stack<T> tempStack= stack;
 int middle= stackSize/2;
}

// ============================================================================
// Question 4: Next Greater Element
// ============================================================================
template <typename T> std::vector<T> nextGreaterElement(Stack<T> stack) {
  // TODO: Implement This
}

} // namespace StackUtils

#endif // STACK_QUESTIONS_NON_MEMBER_TPP
