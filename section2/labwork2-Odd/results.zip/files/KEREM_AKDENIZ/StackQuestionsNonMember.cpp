#include "StackQuestionsNonMember.h"
#include <algorithm>
#include <cctype>
#include <sstream>
#include <stdexcept>

namespace StackUtils {

int longestValidParentheses(const std::string &s) {
  // TODO: Implementation
	




}

} // namespace StackUtils
